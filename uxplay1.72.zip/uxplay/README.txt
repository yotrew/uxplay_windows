1.先安裝Bonjour service(Bonjour64.msi或Bonjour.msi) (僅一次即可)
2.設定防火牆允許通過uxplay.exe (僅一次即可)
3.直接執行uxplay.exe