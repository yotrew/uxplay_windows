#pragma once

#include <gst/gst.h>

G_BEGIN_DECLS

#define GST_D3D11_WINAPI_ONLY_APP 0
#define GST_D3D11_WINAPI_APP 0

G_END_DECLS
